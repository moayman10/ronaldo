﻿using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models
{
    public class TaskmanagmentContext:DbContext
    {
        public DbSet<task> tasks { get; set; }
        public DbSet<project> projects { get; set; }
        public DbSet<teammember> teammembers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=FS-COMLAB3-PC13;Initial Catalog=TaskManagment;Persist Security Info=True;User ID=sa;Password=FIATS@2024;Trust Server Certificate=True");
            base.OnConfiguring(optionsBuilder);
            
        }
    }
}
