﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class teammember
    {
        [Key,DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int memberId { get; set; }
        public string memberName { get; set; }
        public string memberEmail { get; set; }
        public string memberRole { get; set; }
        public List<task> tasks { get; set; }
    }
}
