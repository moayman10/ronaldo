﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class teammemberController : Controller
    {
        TaskmanagmentContext context = new TaskmanagmentContext();
        public IActionResult Index()
        {
            List<teammember> teammember = context.teammembers.ToList();
            return View(teammember);
        }
        public IActionResult Deatials(int ? id)
        {
            teammember teammember = context.teammembers.Include(t => t.tasks).FirstOrDefault(x => x.memberId == id);
            return View(teammember);
        }
        public IActionResult Update(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var teammember = context.teammembers.FirstOrDefault(t => t.memberId == id);
            if (teammember == null)
            {
                return NotFound();
            }
            return View(teammember);
        }
        [HttpPost]
        public IActionResult Update(teammember teammember)
        {
            context.teammembers.Update(teammember);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
