﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class taskController : Controller
    {
        TaskmanagmentContext context = new TaskmanagmentContext();
        public IActionResult Index()
        {
            List<task> task = context.tasks.ToList();
            return View(task);
        }
        
        public IActionResult Update(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var task = context.tasks.FirstOrDefault(t => t.Id == id);
            if (task == null)
            {
                return NotFound();
            }
            return View(task);
        }
        [HttpPost]
        public IActionResult Update(task task)
        {
            context.tasks.Update(task);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        //public IActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return BadRequest();
        //    }
        //    var o1 = context.tasks.FirstOrDefault(t => t.Id == id);
        //    if (o1 == null)
        //    {
        //        return NotFound();
        //    }
        //    return View(o1);
        //}
        //[HttpPost]
        //public IActionResult Edit(int id, string status)
        //{
        //    var oop = context.tasks.FirstOrDefault(t => t.Id == id);
        //    oop.Status = status;
        //    context.SaveChanges();
        //    return RedirectToAction("Index1");
        //}
    }
}
