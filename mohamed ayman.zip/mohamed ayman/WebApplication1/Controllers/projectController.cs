﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class projectController : Controller
    {

        TaskmanagmentContext context = new TaskmanagmentContext();
        public IActionResult Index()
        {
            List<project> project = context.projects.ToList();
            return View(project);
        }
        public IActionResult Details(int ? id)
        {
            project project = context.projects.Include(t => t.tasks).FirstOrDefault(x => x.ProjectId == id);
            return View(project);
        }
        public IActionResult Detail(int? id)
        {
            project project = context.projects.Include(t => t.tasks).FirstOrDefault(x => x.ProjectId == id);
            return View(project);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(project project)
        {
            if (project==null)
            {
                return BadRequest();
            }
      
            context.projects.Add(project);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var project = context.projects.FirstOrDefault(t => t.ProjectId == id);
            if (project == null)
            {
                return NotFound();
            }
            return View(project);
        }
        [HttpPost]
        public IActionResult Update(project project)
        {
            context.projects.Update(project);
            context.SaveChanges();
            return RedirectToAction("Index");
        }



        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var o1 = context.projects.FirstOrDefault(t => t.ProjectId == id);
            if (o1 == null)
            {
                return NotFound();
            }
            context.projects.Remove(o1);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
